from hdnhd_utils import *
from pprint import pprint

imgbytes = load_image_bytes('https://www.fearfreehappyhomes.com/wp-content/uploads/2022/05/Depositphotos_53301473_XL-1200x765.jpg')
labels = detect_image_labels(imgbytes)
pprint(labels)
