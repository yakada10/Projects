import hdnhd_utils
from hdnhd_utils import *


def label_image(user_input, top_text, bottom_text):
    """
    Creates and returns a copy of the image, labeled as either Hot Dog or Not Hot Dog
    based off of the results from GCP Vision API.
    :param img: a string that is either the URL or filename for the image
    :return: a copy of the image labeled as either Hot Dog or Not Hot Dog
    """
    # TODO: replace pass with your code
    if top_text == 'yes':
        imgbytes = load_image_bytes(user_input)
        img = create_pillow_img(imgbytes)
        img_width, img_height = img.size
        top_text_size = text_rect_size(top_text, ImageFont.truetype('ariblk.ttf', 50))
        img = add_text_to_img(img, 'Hot Dog',
        pos=(img_width / 2 - top_text_size[0] / 2, 0),
        color=(255, 255, 255),
        bgcolor=(0, 255, 0, 255), columns=60,
        font=ImageFont.truetype('ariblk.ttf', 50))
        img.show()
        return img
    elif bottom_text == 'yes':
        imgbytes = load_image_bytes(user_input)
        img = create_pillow_img(imgbytes)
        img_width, img_height = img.size
        bottom_text_size = text_rect_size(bottom_text, ImageFont.truetype('ariblk.ttf', 50))
        print(bottom_text_size)
        img = add_text_to_img(img, 'Not Hot Dog',
        pos=(img_width / 2 - bottom_text_size[0] - bottom_text_size[0] + bottom_text_size[0] / 3, img_height - bottom_text_size[1]),
        color=(255, 255, 255),
        bgcolor=(255, 0, 0, 255), columns=60,
        font=ImageFont.truetype('ariblk.ttf', 50))
        img.show()
        return img
    else:
        print('Invalid URL or File')
        exit(0)

def main():
    """
    Main function that runs the program.
    """
    # URLs for some sample images to try
    # NOTE: the TAs may use other images for testing your program
    # Hot Dog
    #img = 'https://upload.wikimedia.org/wikipedia/commons/b/b1/Hot_dog_with_mustard.png'
    # Not Hot Dog (Pizza)
    # img = 'https://render.fineartamerica.com/images/rendered/default/poster/8/10/break/images/artworkimages/medium/1/pizza-slice-diane-diederich.jpg'
    # The image below is an example of a hot dog that is not labeled as a hot dog
    # since your program relies on GCP Vision API, which is not perfect,
    # such an image will be (mis-)labeled as Not Hot Dog by your program
    # that is the expected behavior, you don't need to build your own better hot dog detector ;)
    # img = 'https://i.kinja-img.com/gawker-media/image/upload/s--6RyJpgBM--/c_scale,f_auto,fl_progressive,q_80,w_800/tmlwln8revg44xz4f0tj.jpg'
    # TODO: your code to read the URL/filename from the user
    user_input = input('Enter either a URL or filename for an image:').strip()
    # TODO: and then call label_image
    h = hdnhd_utils.detect_image_labels(user_input)
    yeshotdog = False
    nohotdog = False
    for x in h:
        res_dct = dict(x)
        lol = res_dct["description"]
    # TODO: and then finally show the image returned by the call to label_image
        substring = 'Hot dog'
        if substring in lol:
            yeshotdog = True
        else:
            nohotdog = True
    if yeshotdog:
        ishotdog = 'yes'
    else:
        ishotdog = 'no'
    if nohotdog:
        nhotdog = 'yes'
    else:
        nhotdog = 'no'
    label_image(user_input, ishotdog, nhotdog)


if __name__ == "__main__":
    main()
