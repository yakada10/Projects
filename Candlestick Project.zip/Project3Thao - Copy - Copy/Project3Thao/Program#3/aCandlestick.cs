﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project3
{
    internal class aCandlestick
    {
        // Class that represents a candlestick object in a stock chart.
        // Properties of the candlestick object. They store data about the candlestick.
        public string Ticker { get; set; }
         
        public string Period { get; set; }
        public DateTime Date { get; set; }

        public double High { get; set; }
        public double Open { get; set; }

        public double Close { get; set; }


        public double Low { get; set; }

        public double Volume { get; set; }
        // Constructors for the candlestick object
        public aCandlestick() 
        {
            // Default constructor that initializes properties to default values
            Date = DateTime.Now;
            Open = 0;
            Close = 0;
            Low = 0;
            Volume = 0;
            High = 0;
            Ticker = string.Empty;
            Period = string.Empty;
        
        }

        public aCandlestick(aCandlestick cs)
        {
            // Constructor that copies properties from an existing candlestick object
            Date = cs.Date;
            Open = cs.Open;
            High = cs.High;
            Open = cs.Open;
            Close = cs.Close;
            Volume = cs.Volume;
            Ticker = cs.Ticker;
            Period = cs.Period;
            computeProperties(); // Computes properties of the candlestick object
        }
        // Properties of the candlestick object that are derived from its main properties
        public double range { get; private set; }

        public double body { get; private set; }

        public double topPrice { get; private set; }
        public double bottomPrice { get; private set; }
        public double UpperTail { get; private set; }
        public double LowerTail { get; private set; }

        // A DataTable that holds the data source for the candlestick object
        public static DataTable Datasource { get; internal set; }

        // Properties that indicate the type of marubozu
        public Boolean isMarubozu { get; private set; }
        public Boolean isWhiteMarubozu { get; private set; }
        public Boolean isBlackMarubozu { get; private set; }

        // Properties that indicate the type of candlestick
        public Boolean isBullish { get; private set; }
        public Boolean isBearish { get; private set; }
        public Boolean isNeutral { get; private set; }

        // Properties that indicate the type of hammer
        public Boolean isHammer { get; private set; }
        public Boolean isBullishHammer { get; private set; }
        public Boolean isBearishHammer { get; private set; }
        public Boolean isInvertedHammer { get; private set; }
        public Boolean isBullishInvertedHammer { get; private set; }
        public Boolean isBearishInvertedHammer { get; private set; }

        // Properties that indicate the type of doji
        public Boolean isDoji { get; private set; }
        public Boolean isGravestoneDoji { get; private set; }
        public Boolean isNeutralDoji { get; private set; }
        public Boolean isDragonflyDoji { get; private set; }
        public Boolean isLongLeggedDoji { get; private set; }

        // Determines if the candlestick is there respective pattern
        public Boolean dojiTest(double bodyTolerance = 0.03)
        {
            return body <= bodyTolerance * range;
        }

        public Boolean dragonflyDoji(double bodyTolerance = 0.03)
        {
            return dojiTest(bodyTolerance);
        }
        public Boolean neutralDojiTest(double bodyTolerance = 0.03)
        {
            return dojiTest(bodyTolerance);
        }
        public Boolean GravestoneDojiTest(double bodyTolerance = 0.03)
        {
            return dojiTest(bodyTolerance);
        }
        public Boolean hammerTest(double bodyTolerance = 0.03)
        {
            return body > 1.00;
        }
        public Boolean bullishHammerTest(double bodyTolerance = 0.03)
        {
            return hammerTest(bodyTolerance) && isBullish == true;
        }
        public Boolean bearishHammerTest(double bodyTolerance = 0.03)
        {
            return hammerTest(bodyTolerance) && isBearish == true;
        }
        public Boolean invertedHammerTest(double bodyTolerance = 0.03)
        {
            return body > 1.00;
        }
        public Boolean bullishInvertedHammerTest(double bodyTolerance = 0.03)
        {
            return invertedHammerTest(bodyTolerance) && isBullish == true;
        }
        public Boolean bearishInvertedHammerTest(double bodyTolerance = 0.03)
        {
            return invertedHammerTest(bodyTolerance) && isBearish == true;
        }
        public Boolean marubozuTest(double bodyTolerance = 0.03)
        {
            return body > range * (1 - bodyTolerance);
        }
        public Boolean whiteMarubozuTest(double bodyTolerance = 0.03)
        {
            return marubozuTest(bodyTolerance) && isBullish == true;
        }
        public Boolean blackMarubozuTest(double bodyTolerance = 0.03)
        {
            return marubozuTest(bodyTolerance) && isBearish == true;
        }

        public Boolean DoubleRecognizerTest (double bodyTolerance = 0.03)
        {
            return body > 0.3;
        }

        // Constructor for aCandlestick class with input arguments
        public aCandlestick(DateTime date, double open, double high, double low, double close, long volume)
        {
            // Set the public properties to the input arguments
            Date = date;
            High = high;
            Open = open;
            Close = close;
            Low = low;
            Volume = volume;

            computeProperties();
        }

        // Compute the different patterns based on the private properties
        private void computePatterns()
        {
            isBullish = Close > Open;
            isBearish = Open > Close;
            isNeutral = Open == Close;

            isMarubozu = marubozuTest();
            isWhiteMarubozu = whiteMarubozuTest();
            isBlackMarubozu = blackMarubozuTest();
            isHammer = hammerTest();
            isBullishHammer = bullishHammerTest();
            isBearishHammer = bearishHammerTest();
            isInvertedHammer = invertedHammerTest();
            isBullishInvertedHammer = bullishInvertedHammerTest();
            isBearishInvertedHammer = bearishInvertedHammerTest();
            isDoji = dojiTest();
            isDragonflyDoji = dragonflyDoji();
            isNeutralDoji = neutralDojiTest();
            isGravestoneDoji = GravestoneDojiTest();


        }

        // Compute the private properties based on the public properties
        private void computeProperties()
        {
            range = High - Low;
            body = Math.Max(Open, Close) - Math.Min(Close, Open);
            topPrice = Math.Max(Open, Close);
            bottomPrice = Math.Min(Open, Close);
            UpperTail = High - topPrice;
            LowerTail = bottomPrice - Low;

            computePatterns();
        }

        // Copy constructor for aCandlestick class with input arguments
        public aCandlestick(DateTime Date, double Open, double High, double Low, double Close, double Adj, long Volume)
        {
            // Set the public properties to the input arguments

            this.Date = Date;
            this.Open = Open;
            this.High = High;
            this.Low = Low;
            this.Close = Close;
            this.Volume = Volume;

            

            computeProperties();
        }

  

    }

}

