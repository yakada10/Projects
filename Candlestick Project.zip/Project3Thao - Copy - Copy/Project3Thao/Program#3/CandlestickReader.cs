﻿using System.Collections.Generic;
using System;

namespace Project3
{
    internal class CandlestickReader
    {
        //public List<aCandlestick> candlesticks;

        // The constant string for the folder where the stock data is stored
        const string dataFolder = "Stock Data";

        // The list of candlesticks that will be populated by the class
        public List<aCandlestick> listOfCandlesticks = null;

        // The ticker symbol for the stock being read
        public string Ticker { get; private set; }

        // CONSTRUCTOR initializes listOfCandlesticks
        public CandlestickReader()
        {
            listOfCandlesticks = new List<aCandlestick>(256);
        }

        /// <summary>
        /// Reads the candlestick data from the specified CSV file for the specified time period.
        /// </summary>
        /// <param name="csvFilename">The filename of the CSV file containing the candlestick data.</param>
        /// <param name="startdate">The starting date of the time period to read.</param>
        /// <param name="enddate">The ending date of the time period to read.</param>
        /// <returns>A list of candlesticks for the specified time period.</returns>
        public List<aCandlestick> readlistOfCandlesticks(string csvFilename, DateTime startdate, DateTime enddate)
        {
            // The characters to use as separators when parsing the CSV file
            char[] seperators = new char[] { '/', ',', '"' };

            // Get all lines in the CSV file as a string array
            String[] lines = System.IO.File.ReadAllLines(csvFilename);

            // Skip header line, and make sure it's valid
            String header = lines[0];
            if (header == "Date,Open,High,Low,Close,Adj Close,Volume")
            {
                // Create a new list of candlesticks with enough capacity to hold all lines in the CSV file except the header
                listOfCandlesticks = new List<aCandlestick>(lines.Length - 1);

                // Loop through each line in the CSV file (skipping the header)
                for (int l = 1; l < lines.Length; l++)
                {
                    // Get the l-th line
                    String line = lines[l].Trim();

                    // Split the line into substrings based on the specified separators
                    string[] subString = line.Split(seperators, StringSplitOptions.RemoveEmptyEntries);

                    // Parse the year, month, and day from the date string, and create a new DateTime object
                    int month = int.Parse(subString[0]);
                    int day = int.Parse(subString[1]);
                    int year = int.Parse(subString[2]);
                    DateTime date = new DateTime(year, month, day);

                    // If the date is within the specified time period, parse the remaining values from the line and create a new Candlestick object
                    if (date.CompareTo(startdate) >= 0 && date.CompareTo(enddate) <= 0)
                    {
                        double Open = double.Parse(subString[3]);
                        double High = double.Parse(subString[4]);
                        double low = double.Parse(subString[5]);
                        double close = double.Parse(subString[6]);
                        double adj = double.Parse(subString[7]);
                        long volume = long.Parse(subString[8]);

                        // Round the open, high, low, close, and adj values to two decimal places
                        Open = Math.Round(Open, 2);
                        High = Math.Round(High, 2);
                        low = Math.Round(low, 2);
                        close = Math.Round(close, 2);
                        adj = Math.Round(adj, 2);
                        // volume = Math.Round(adj, 2);


                        ///create new candlestick 
                        aCandlestick candlestick = new aCandlestick(date, Open, High, low, close, adj, volume);
                        /// add newly created candlestick to listOfcandlesticks
                        listOfCandlesticks.Add(candlestick);
                    }

                }
            }

            return listOfCandlesticks;
        }

        public List<aCandlestick> readStock(String ticker, DateTime startDate, DateTime endDate)

        /// create filename for ticker by concatenating the folder ticker and period 
        {
            String csvFilename = dataFolder + @"\" + ticker;
            /// read candlestick and return listofcandlestick memeber 
            listOfCandlesticks = readlistOfCandlesticks(csvFilename, startDate, endDate);
            return listOfCandlesticks;

        }

    }
}
