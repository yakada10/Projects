﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace Project3
{
    public partial class FormStartCandle : Form
    {
        // Fields
        private CandlestickReader ACandleStickr = null;
        private List<aCandlestick> listOfCandleSticks = null;
        private FileInfo[] Files = null;

        // Static instance of the form
        public static FormStartCandle instance;

        // Constructor
        public FormStartCandle()
        {
            InitializeComponent();

            // Initialize the candlestick reader
            ACandleStickr = new CandlestickReader();

            // Set the instance to this form
            instance = this;

            // Get the directory where the stock data is stored
            string fileName = Path.GetDirectoryName(System.AppDomain.CurrentDomain.BaseDirectory);
            string filepath = fileName + "/Stock Data/";
            DirectoryInfo d = new DirectoryInfo(filepath);

            // Get all the CSV files in the directory
            Files = d.GetFiles("*.csv");
        }

        // Method to handle the button click event
        private void button1_Click(object sender, EventArgs e)
        {
            // Get the filename pattern based on the selected radio button
            string targetFilenamePattern = String.Empty;

            if (RadioDay.Checked)
            {
                targetFilenamePattern = "Day";
            }
            else if (RadioWeek.Checked)
            {
                targetFilenamePattern = "Week";
            }
            else if (RadioMonth.Checked)
            {
                targetFilenamePattern = "Month";
            }
            else
            {
                targetFilenamePattern = "Day";
            }

            // Create a new chart form
            FormStartChart formgraph = new FormStartChart();

            // Read the stock data and set it as the data source for the chart
            listOfCandleSticks = ACandleStickr.readStock(comboBox_File.Text, startDate.Value, endDate.Value);
            formgraph.chartStock.DataSource = listOfCandleSticks;

            // Show the chart form
            formgraph.Show();
        }

        // Method to handle the "day" radio button checked event
        private void radioButtonDay_CheckedChanged(object sender, EventArgs e)
        {
            // Set the filename pattern to "Day" and populate the combo box with the corresponding files
            string targetFilenamePattern = "Day";
            comboBox_File.Items.Clear();
            foreach (FileInfo file in Files)
            {
                if ((file.Name).Contains(targetFilenamePattern))
                {
                    comboBox_File.Items.Add(file.Name);
                }
            }

            Controls.Add(comboBox_File);
        }

        // Method to handle the "week" radio button checked event
        private void radioButtonweek_CheckedChanged(object sender, EventArgs e)
        {
            // Set the filename pattern to "Week" and populate the combo box with the corresponding files
            string targetFilenamePattern = "Week";
            comboBox_File.Items.Clear();
            foreach (FileInfo file in Files)
            {
                if ((file.Name).Contains(targetFilenamePattern))
                {
                    comboBox_File.Items.Add(file.Name);
                }
            }

            Controls.Add(comboBox_File);
        }

        // Method to handle the "month" radio button checked event
        private void radioButtonmonth_CheckedChanged(object sender, EventArgs e)
        {
            // Set the filename pattern to "Month" and populate the combo box with the corresponding files
            string targetFilenamePattern = "Month";
            comboBox_File.Items.Clear();
            foreach (FileInfo file in Files)
            {
                if ((file.Name).Contains(targetFilenamePattern))
                {
                    comboBox_File.Items.Add(file.Name);
                }
            }
            Controls.Add(comboBox_File);




        }

        private void FormSelectInFormation_Load(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void comboBoxForPatterns_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
