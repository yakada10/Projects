﻿namespace Project3
{
    partial class FormStartCandle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox_Period = new System.Windows.Forms.GroupBox();
            this.RadioMonth = new System.Windows.Forms.RadioButton();
            this.RadioWeek = new System.Windows.Forms.RadioButton();
            this.RadioDay = new System.Windows.Forms.RadioButton();
            this.comboBox_File = new System.Windows.Forms.ComboBox();
            this.labelticker = new System.Windows.Forms.Label();
            this.labelStartDate = new System.Windows.Forms.Label();
            this.labelEnddate = new System.Windows.Forms.Label();
            this.startDate = new System.Windows.Forms.DateTimePicker();
            this.endDate = new System.Windows.Forms.DateTimePicker();
            this.button_load = new System.Windows.Forms.Button();
            this.aCandlestickBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.groupBox_Period.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.aCandlestickBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox_Period
            // 
            this.groupBox_Period.Controls.Add(this.RadioMonth);
            this.groupBox_Period.Controls.Add(this.RadioWeek);
            this.groupBox_Period.Controls.Add(this.RadioDay);
            this.groupBox_Period.Location = new System.Drawing.Point(229, 29);
            this.groupBox_Period.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox_Period.Name = "groupBox_Period";
            this.groupBox_Period.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox_Period.Size = new System.Drawing.Size(103, 92);
            this.groupBox_Period.TabIndex = 0;
            this.groupBox_Period.TabStop = false;
            this.groupBox_Period.Text = "Period";
            // 
            // RadioMonth
            // 
            this.RadioMonth.AutoSize = true;
            this.RadioMonth.Location = new System.Drawing.Point(15, 60);
            this.RadioMonth.Margin = new System.Windows.Forms.Padding(2);
            this.RadioMonth.Name = "RadioMonth";
            this.RadioMonth.Size = new System.Drawing.Size(62, 17);
            this.RadioMonth.TabIndex = 2;
            this.RadioMonth.TabStop = true;
            this.RadioMonth.Text = "Monthly";
            this.RadioMonth.UseVisualStyleBackColor = true;
            this.RadioMonth.CheckedChanged += new System.EventHandler(this.radioButtonmonth_CheckedChanged);
            // 
            // RadioWeek
            // 
            this.RadioWeek.AutoSize = true;
            this.RadioWeek.Location = new System.Drawing.Point(15, 40);
            this.RadioWeek.Margin = new System.Windows.Forms.Padding(2);
            this.RadioWeek.Name = "RadioWeek";
            this.RadioWeek.Size = new System.Drawing.Size(61, 17);
            this.RadioWeek.TabIndex = 1;
            this.RadioWeek.TabStop = true;
            this.RadioWeek.Text = "Weekly";
            this.RadioWeek.UseVisualStyleBackColor = true;
            this.RadioWeek.CheckedChanged += new System.EventHandler(this.radioButtonweek_CheckedChanged);
            // 
            // RadioDay
            // 
            this.RadioDay.AutoSize = true;
            this.RadioDay.Location = new System.Drawing.Point(15, 18);
            this.RadioDay.Margin = new System.Windows.Forms.Padding(2);
            this.RadioDay.Name = "RadioDay";
            this.RadioDay.Size = new System.Drawing.Size(48, 17);
            this.RadioDay.TabIndex = 0;
            this.RadioDay.TabStop = true;
            this.RadioDay.Text = "Daily";
            this.RadioDay.UseVisualStyleBackColor = true;
            this.RadioDay.CheckedChanged += new System.EventHandler(this.radioButtonDay_CheckedChanged);
            // 
            // comboBox_File
            // 
            this.comboBox_File.FormattingEnabled = true;
            this.comboBox_File.Location = new System.Drawing.Point(57, 280);
            this.comboBox_File.Margin = new System.Windows.Forms.Padding(2);
            this.comboBox_File.Name = "comboBox_File";
            this.comboBox_File.Size = new System.Drawing.Size(275, 21);
            this.comboBox_File.TabIndex = 1;
            this.comboBox_File.SelectedIndexChanged += new System.EventHandler(this.comboBoxForPatterns_SelectedIndexChanged);
            // 
            // labelticker
            // 
            this.labelticker.AutoSize = true;
            this.labelticker.Location = new System.Drawing.Point(58, 265);
            this.labelticker.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelticker.Name = "labelticker";
            this.labelticker.Size = new System.Drawing.Size(59, 13);
            this.labelticker.TabIndex = 2;
            this.labelticker.Text = "Select File:";
            // 
            // labelStartDate
            // 
            this.labelStartDate.AutoSize = true;
            this.labelStartDate.Location = new System.Drawing.Point(58, 141);
            this.labelStartDate.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelStartDate.Name = "labelStartDate";
            this.labelStartDate.Size = new System.Drawing.Size(58, 13);
            this.labelStartDate.TabIndex = 3;
            this.labelStartDate.Text = "Start Date:";
            // 
            // labelEnddate
            // 
            this.labelEnddate.AutoSize = true;
            this.labelEnddate.Location = new System.Drawing.Point(58, 207);
            this.labelEnddate.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelEnddate.Name = "labelEnddate";
            this.labelEnddate.Size = new System.Drawing.Size(55, 13);
            this.labelEnddate.TabIndex = 4;
            this.labelEnddate.Text = "End Date:";
            // 
            // startDate
            // 
            this.startDate.Location = new System.Drawing.Point(57, 156);
            this.startDate.Margin = new System.Windows.Forms.Padding(2);
            this.startDate.Name = "startDate";
            this.startDate.Size = new System.Drawing.Size(275, 20);
            this.startDate.TabIndex = 5;
            this.startDate.Value = new System.DateTime(2022, 1, 1, 0, 0, 0, 0);
            // 
            // endDate
            // 
            this.endDate.Location = new System.Drawing.Point(57, 222);
            this.endDate.Margin = new System.Windows.Forms.Padding(2);
            this.endDate.Name = "endDate";
            this.endDate.Size = new System.Drawing.Size(275, 20);
            this.endDate.TabIndex = 6;
            this.endDate.Value = new System.DateTime(2022, 12, 1, 0, 0, 0, 0);
            // 
            // button_load
            // 
            this.button_load.Location = new System.Drawing.Point(56, 328);
            this.button_load.Margin = new System.Windows.Forms.Padding(2);
            this.button_load.Name = "button_load";
            this.button_load.Size = new System.Drawing.Size(276, 82);
            this.button_load.TabIndex = 7;
            this.button_load.Text = "Load";
            this.button_load.UseVisualStyleBackColor = true;
            this.button_load.Click += new System.EventHandler(this.button1_Click);
            // 
            // FormStartCandle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ClientSize = new System.Drawing.Size(406, 446);
            this.Controls.Add(this.button_load);
            this.Controls.Add(this.endDate);
            this.Controls.Add(this.startDate);
            this.Controls.Add(this.labelEnddate);
            this.Controls.Add(this.labelStartDate);
            this.Controls.Add(this.labelticker);
            this.Controls.Add(this.comboBox_File);
            this.Controls.Add(this.groupBox_Period);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "FormStartCandle";
            this.Text = "Start Candle:";
            this.Load += new System.EventHandler(this.FormSelectInFormation_Load);
            this.groupBox_Period.ResumeLayout(false);
            this.groupBox_Period.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.aCandlestickBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox_Period;
        private System.Windows.Forms.ComboBox comboBox_File;
        private System.Windows.Forms.Label labelticker;
        private System.Windows.Forms.Label labelStartDate;
        private System.Windows.Forms.Label labelEnddate;
        private System.Windows.Forms.DateTimePicker startDate;
        private System.Windows.Forms.DateTimePicker endDate;
        private System.Windows.Forms.RadioButton RadioMonth;
        private System.Windows.Forms.RadioButton RadioWeek;
        private System.Windows.Forms.RadioButton RadioDay;
        private System.Windows.Forms.Button button_load;
        private System.Windows.Forms.BindingSource aCandlestickBindingSource;
    }
}

