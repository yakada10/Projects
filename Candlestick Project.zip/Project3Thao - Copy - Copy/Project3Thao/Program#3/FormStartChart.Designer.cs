﻿namespace Project3
{
    partial class FormStartChart
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.chartStock = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.comboBox_Pattern = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.chartStock)).BeginInit();
            this.SuspendLayout();
            // 
            // chartStock
            // 
            chartArea1.Name = "OHLC";
            this.chartStock.ChartAreas.Add(chartArea1);
            this.chartStock.Dock = System.Windows.Forms.DockStyle.Top;
            legend1.Name = "Legend1";
            this.chartStock.Legends.Add(legend1);
            this.chartStock.Location = new System.Drawing.Point(0, 0);
            this.chartStock.Margin = new System.Windows.Forms.Padding(2);
            this.chartStock.Name = "chartStock";
            series1.ChartArea = "OHLC";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Candlestick;
            series1.Legend = "Legend1";
            series1.Name = "OHLC";
            series1.YValuesPerPoint = 4;
            this.chartStock.Series.Add(series1);
            this.chartStock.Size = new System.Drawing.Size(1172, 479);
            this.chartStock.TabIndex = 0;
            this.chartStock.Text = "chart_data";
            // 
            // comboBox_Pattern
            // 
            this.comboBox_Pattern.FormattingEnabled = true;
            this.comboBox_Pattern.Location = new System.Drawing.Point(12, 515);
            this.comboBox_Pattern.Margin = new System.Windows.Forms.Padding(2);
            this.comboBox_Pattern.Name = "comboBox_Pattern";
            this.comboBox_Pattern.Size = new System.Drawing.Size(150, 21);
            this.comboBox_Pattern.TabIndex = 1;
            this.comboBox_Pattern.SelectedIndexChanged += new System.EventHandler(this.comboBoxStockPattern_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 500);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Pattern:";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // FormStartChart
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ClientSize = new System.Drawing.Size(1172, 563);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.comboBox_Pattern);
            this.Controls.Add(this.chartStock);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "FormStartChart";
            this.Text = "Chart Display:";
            this.Load += new System.EventHandler(this.FormChart_Load);
            ((System.ComponentModel.ISupportInitialize)(this.chartStock)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.DataVisualization.Charting.Chart chartStock;
        private System.Windows.Forms.ComboBox comboBox_Pattern;
        private System.Windows.Forms.Label label2;
    }
}