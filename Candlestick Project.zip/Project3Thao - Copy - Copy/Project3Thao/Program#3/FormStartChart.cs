﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using static Project3.Recognizer_NeutralDoji;
using static Project3.Recognizer_NeutralDoji.Recognizer_GravestoneDoji;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Project3
{
    public partial class FormStartChart : Form
    {

        // List to hold all the candlesticks
        List<aCandlestick> candlesticks = new List<aCandlestick>();

        public FormStartChart()
        {
            /// Initializes the Chart and it's properties
            InitializeComponent();
            initializeRecognizer();

            /// Sets X value to Date component
            chartStock.Series["OHLC"].XValueMember = "Date";

            /// Gives Y value 4 parts
            chartStock.Series["OHLC"].YValuesPerPoint = 4;

            /// Sets Y Values parts
            chartStock.Series["OHLC"].YValueMembers = "High, Low, Open, Close";

            /// Removes background lines on the chart
            chartStock.ChartAreas["OHLC"].AxisX.MajorGrid.LineWidth = 0;
            chartStock.ChartAreas["OHLC"].AxisY.MajorGrid.LineWidth = 0;

            /// Sets custom stock values of the chart based on if the open is greater than the close
            chartStock.Series["OHLC"].CustomProperties = "PriceUpColor=Green, PriceDownColor=Red";
        }

        // Method to update the chart
        private void upDateChart()
        {
            // Get the chart's data source and cast it to a List<aCandlestick>
            var dataSource = chartStock.DataSource as List<aCandlestick>;

            if (dataSource != null)
            {
                // Assign the chart's data source to the candlesticks list
                candlesticks = dataSource;

                // Calculate the Y-axis maximum and minimum values
                double maxY = candlesticks.Max(cs => cs.High);
                double minY = candlesticks.Min(cs => cs.Low);
                double padding = 0.10 * (maxY - minY);

                // Set the Y-axis maximum and minimum values
                chartStock.ChartAreas["OHLC"].AxisY.Maximum = maxY + padding;
                chartStock.ChartAreas["OHLC"].AxisY.Minimum = minY - padding;
            }
        }




        // List to hold all the recognizers
        List<aRecognizer> recognizors = new List<aRecognizer>(32);

        // Method to initialize all the recognizers
        private List<aRecognizer> initializeRecognizer()
        {
            aRecognizer recognizor = null;

            // Create an instance of each recognizer and add it to the recognizers list
            recognizor = new Recognizer_Bullish();
            recognizors.Add(recognizor);

            recognizor = new Recognizer_Bearish();
            recognizors.Add(recognizor);

            recognizor = new Recognizer_Neutral();
            recognizors.Add(recognizor);

            recognizor = new Recognizer_NeutralDoji();
            recognizors.Add(recognizor);

            recognizor = new Recognizer_DragonflyDoji();
            recognizors.Add(recognizor);

            recognizor = new Recognizer_GravestoneDoji();
            recognizors.Add(recognizor);

            recognizor = new Recognizer_Hammer();
            recognizors.Add(recognizor);

            recognizor = new Recognizer_BearishHammer();
            recognizors.Add(recognizor);

            recognizor = new Recognizer_InvertedHammer();
            recognizors.Add(recognizor);

            recognizor = new Recognizer_BearishInvertedHammer();
            recognizors.Add(recognizor);

            recognizor = new Recognizer_BlackMarubozu();
            recognizors.Add(recognizor);

            recognizor = new Recognizer_WhiteMarubozu();
            recognizors.Add(recognizor);

            recognizor = new BearishDoubleRecognizer();
            recognizors.Add(recognizor);

            recognizor = new BullishDoubleRecognizer();
            recognizors.Add(recognizor);



            comboBox_Pattern.Items.Clear();
            foreach (aRecognizer r in recognizors)
            {
                comboBox_Pattern.Items.Add(r.patternName);
            }
            comboBox_Pattern.Enabled = true;

            return recognizors;

        }
        // All of the below code will highlight the pattern on the chart by creating a new rectangle annnotation for each data point and the respective pattern that will be chosen.
        // The code will also return true if the body size is less than, greater than, or equal to their respective integer.
        private void HighlightDoji()
        {


            foreach (DataPoint dp in chartStock.Series["OHLC"].Points)
            {
                if (IsDoji(dp.YValues[0], dp.YValues[1], dp.YValues[2], dp.YValues[3]))
                {
                    var rectangleAnnotation = new RectangleAnnotation();
                    rectangleAnnotation.Height = 50;
                    rectangleAnnotation.Width = 7;
                    rectangleAnnotation.LineWidth = 1;
                    rectangleAnnotation.LineDashStyle = ChartDashStyle.Solid;
                    rectangleAnnotation.AnchorDataPoint = dp;
                    rectangleAnnotation.BackColor = Color.Transparent;
                    double x = dp.XValue;

                    rectangleAnnotation.Name = $"Annotation{x}";
                    rectangleAnnotation.Text = $"Common Doji";
                    rectangleAnnotation.IsSizeAlwaysRelative = false;

                    chartStock.Annotations.Add(rectangleAnnotation);
                }
            }


        }

        private bool IsDoji(double low, double high, double open, double close)
        {
            double bodySize = Math.Abs(close - open);
            double range = high - low;
            double dojirange = range * 0.15;

            if (bodySize < dojirange)
            {
                return true;
            }

            return false;
        }
        /// Long LeggedDoji method that highlights any Long Legged Doji by making a new series called "Long Legged Doji" and reads each datapoint to see if they fit the creteria
        private void HighlightLongLeggedDoji()
        {
            var LongdojiSeries = new Series("LOng Legged Doji");
            LongdojiSeries.ChartType = SeriesChartType.Point;
            LongdojiSeries.Color = Color.Indigo;
            LongdojiSeries.MarkerSize = 7;

            foreach (DataPoint dp in chartStock.Series["OHLC"].Points)
            {
                if (IsLongLeggedDoji(dp.YValues[0], dp.YValues[1], dp.YValues[2], dp.YValues[3]))
                {
                    var rectangleAnnotation = new RectangleAnnotation();
                    rectangleAnnotation.Height = 150;
                    rectangleAnnotation.Width = 7;
                    rectangleAnnotation.LineWidth = 1;
                    rectangleAnnotation.LineDashStyle = ChartDashStyle.Solid;
                    rectangleAnnotation.AnchorDataPoint = dp;
                    rectangleAnnotation.BackColor = Color.Transparent;
                    double x = dp.XValue;

                    rectangleAnnotation.Name = $"Annotation{x}";
                    rectangleAnnotation.Text = $"Long Legged Doji";
                    rectangleAnnotation.IsSizeAlwaysRelative = false;

                    chartStock.Annotations.Add(rectangleAnnotation);
                }
            }


        }

        private bool IsLongLeggedDoji(double low, double high, double open, double close)
        {
            double bodySize = Math.Abs(close - open);
            double range = high - low;

            double islongleg = range * 0.07;
            if (bodySize < islongleg)
            {
                return true;
            }

            return false;
        }

        /// Dragonfly Doji method that highlights any Dragonfly Doji by making a new series called "Dragonfly Doji" and reads each datapoint to see if they fit the creteria

        private void HighlightDragonflyDoji()
        {
            var DragondojiSeries = new Series("Dragonfly Doji");
            DragondojiSeries.ChartType = SeriesChartType.Point;
            DragondojiSeries.Color = Color.IndianRed;
            DragondojiSeries.MarkerSize = 7;

            foreach (DataPoint dp in chartStock.Series["OHLC"].Points)
            {
                if (IsDragonDoji(dp.YValues[0], dp.YValues[1], dp.YValues[2], dp.YValues[3]))
                {
                    var rectangleAnnotation = new RectangleAnnotation();
                    rectangleAnnotation.Height = 150;
                    rectangleAnnotation.Width = 7;
                    rectangleAnnotation.LineWidth = 1;
                    rectangleAnnotation.LineDashStyle = ChartDashStyle.Solid;
                    rectangleAnnotation.AnchorDataPoint = dp;
                    rectangleAnnotation.BackColor = Color.Transparent;
                    double x = dp.XValue;

                    rectangleAnnotation.Name = $"Annotation{x}";
                    rectangleAnnotation.Text = $"Dragonfly Doji";
                    rectangleAnnotation.IsSizeAlwaysRelative = false;

                    chartStock.Annotations.Add(rectangleAnnotation);
                }
            }


        }

        private bool IsDragonDoji(double low, double high, double open, double close)
        {
            double bodySize = Math.Abs(close - open);
            double range = high - low;
            double dojirange = range * 0.15;
            double distanceToTop = high - Math.Max(open, close);
            if (bodySize < dojirange && distanceToTop < range * 0.15)
            {
                return true;
            }

            return false;
        }
        /// Gravestone Doji method that highlights any Gravestone Doji by making a new series called "Gravestone Doji" and reads each datapoint to see if they fit the creteria
        private void HighlightGravestoneDoji()
        {
            var DragondojiSeries = new Series("Gravestone Doji");
            DragondojiSeries.ChartType = SeriesChartType.Point;
            DragondojiSeries.Color = Color.Yellow;
            DragondojiSeries.MarkerSize = 7;

            foreach (DataPoint dp in chartStock.Series["OHLC"].Points)
            {
                if (IsGravestoneDoji(dp.YValues[0], dp.YValues[1], dp.YValues[2], dp.YValues[3]))
                {
                    var rectangleAnnotation = new RectangleAnnotation();
                    rectangleAnnotation.Height = 150;
                    rectangleAnnotation.Width = 7;
                    rectangleAnnotation.LineWidth = 1;
                    rectangleAnnotation.LineDashStyle = ChartDashStyle.Solid;
                    rectangleAnnotation.AnchorDataPoint = dp;
                    rectangleAnnotation.BackColor = Color.Transparent;
                    double x = dp.XValue;

                    rectangleAnnotation.Name = $"Annotation{x}";
                    rectangleAnnotation.Text = $"Gravestone Doji";
                    rectangleAnnotation.IsSizeAlwaysRelative = false;

                    chartStock.Annotations.Add(rectangleAnnotation);
                }
            }


        }

        private bool IsGravestoneDoji(double low, double high, double open, double close)
        {
            double bodySize = Math.Abs(close - open);
            double range = high - low;
            double dojirange = range * 0.15;
            double distanceToBottom = Math.Min(open, close) - low;
            if (bodySize < dojirange && distanceToBottom < range * 0.15)
            {
                return true;
            }

            return false;
        }

        ///Hammer method that highlights any Hammer by making a new series called "Hammer" and reads each datapoint to see if they fit the creteria
        private void HighlightHammer()
        {

            foreach (DataPoint dp in chartStock.Series["OHLC"].Points)
            {
                if (IsHammer(dp.YValues[0], dp.YValues[1], dp.YValues[2], dp.YValues[3]))
                {
                    var rectangleAnnotation = new RectangleAnnotation();
                    rectangleAnnotation.Height = 150;
                    rectangleAnnotation.Width = 7;
                    rectangleAnnotation.LineWidth = 1;
                    rectangleAnnotation.LineDashStyle = ChartDashStyle.Solid;
                    rectangleAnnotation.AnchorDataPoint = dp;
                    rectangleAnnotation.BackColor = Color.Transparent;
                    double x = dp.XValue;

                    rectangleAnnotation.Name = $"Annotation{x}";
                    rectangleAnnotation.Text = $"Hammer";
                    rectangleAnnotation.IsSizeAlwaysRelative = false;

                    chartStock.Annotations.Add(rectangleAnnotation);
                }
            }


        }

        private bool IsHammer(double low, double high, double open, double close)
        {
            double bodySize = Math.Abs(close - open);
            double range = high - low;
            double distanceToTop = high - Math.Max(open, close);
            bool IsBullish = close > open;

            if (IsBullish == true && distanceToTop < range * 0.1)
            {
                return true;
            }

            return false;
        }
        /// Inverted Hammer method that highlights any Inverted Hammer by making a new series called "Inverted Hammer" and reads each datapoint to see if they fit the creteria
        private void HighlightInvertedHammer()
        {

            foreach (DataPoint dp in chartStock.Series["OHLC"].Points)
            {
                if (IsInvertedHammer(dp.YValues[0], dp.YValues[1], dp.YValues[2], dp.YValues[3]))
                {
                    var rectangleAnnotation = new RectangleAnnotation();
                    rectangleAnnotation.Height = 150;
                    rectangleAnnotation.Width = 7;
                    rectangleAnnotation.LineWidth = 1;
                    rectangleAnnotation.LineDashStyle = ChartDashStyle.Solid;
                    rectangleAnnotation.AnchorDataPoint = dp;
                    rectangleAnnotation.BackColor = Color.Transparent;
                    double x = dp.XValue;

                    rectangleAnnotation.Name = $"Annotation{x}";
                    rectangleAnnotation.Text = $"Inverted Hammer";
                    rectangleAnnotation.IsSizeAlwaysRelative = false;

                    chartStock.Annotations.Add(rectangleAnnotation);
                }
            }


        }

        private bool IsInvertedHammer(double low, double high, double open, double close)
        {
            double bodySize = Math.Abs(close - open);
            double range = high - low;
            double distanceToBottom = Math.Min(open, close) - low;
            bool IsBullish = close > open;

            if (IsBullish == true && distanceToBottom < range * 0.1)
            {
                return true;
            }

            return false;
        }
        /// Shooting Star method that highlights any Shooting Star by making a new series called "Shooting Star" and reads each datapoint to see if they fit the creteria
        private void HighlightShootingStar()
        {

            foreach (DataPoint dp in chartStock.Series["OHLC"].Points)
            {
                if (IsShootingStar(dp.YValues[0], dp.YValues[1], dp.YValues[2], dp.YValues[3]))
                {
                    var rectangleAnnotation = new RectangleAnnotation();
                    rectangleAnnotation.Height = 150;
                    rectangleAnnotation.Width = 7;
                    rectangleAnnotation.LineWidth = 1;
                    rectangleAnnotation.LineDashStyle = ChartDashStyle.Solid;
                    rectangleAnnotation.AnchorDataPoint = dp;
                    rectangleAnnotation.BackColor = Color.Transparent;
                    double x = dp.XValue;

                    rectangleAnnotation.Name = $"Annotation{x}";
                    rectangleAnnotation.Text = $"Shooting Star";
                    rectangleAnnotation.IsSizeAlwaysRelative = false;

                    chartStock.Annotations.Add(rectangleAnnotation);
                }
            }


        }

        private bool IsShootingStar(double low, double high, double open, double close)
        {
            double bodySize = Math.Abs(close - open);
            double range = high - low;
            double distanceToBottom = Math.Min(open, close) - low;
            bool IsBearish = close > open;

            if (IsBearish == true && distanceToBottom < range * 0.1)
            {
                return true;
            }

            return false;
        }
        /// Hangman method that highlights any Hangman by making a new series called "Hangman" and reads each datapoint to see if they fit the creteria
        private void HighlightHangman()
        {

            foreach (DataPoint dp in chartStock.Series["OHLC"].Points)
            {
                if (IsHangman(dp.YValues[0], dp.YValues[1], dp.YValues[2], dp.YValues[3]))
                {
                    var rectangleAnnotation = new RectangleAnnotation();
                    rectangleAnnotation.Height = 150;
                    rectangleAnnotation.Width = 7;
                    rectangleAnnotation.LineWidth = 1;
                    rectangleAnnotation.LineDashStyle = ChartDashStyle.Solid;
                    rectangleAnnotation.AnchorDataPoint = dp;
                    rectangleAnnotation.BackColor = Color.Transparent;
                    double x = dp.XValue;

                    rectangleAnnotation.Name = $"Annotation{x}";
                    rectangleAnnotation.Text = $"Hangman";
                    rectangleAnnotation.IsSizeAlwaysRelative = false;

                    chartStock.Annotations.Add(rectangleAnnotation);
                }
            }


        }

        private bool IsHangman(double low, double high, double open, double close)
        {
            double bodySize = Math.Abs(close - open);
            double range = high - low;
            double distanceToTop = high - Math.Max(open, close);
            bool IsBearish = close < open;

            if (IsBearish == true && distanceToTop < range * 0.1)
            {
                return true;
            }

            return false;
        }
        /// White Marubozu method that highlights any White Marubozu by making a new series called "White Marubozu" and reads each datapoint to see if they fit the creteria
        private void HighlightWhiteMarubozu()
        {


            foreach (DataPoint dp in chartStock.Series["OHLC"].Points)
            {
                if (IsWhiteMarubozu(dp.YValues[0], dp.YValues[1], dp.YValues[2], dp.YValues[3]))
                {
                    var rectangleAnnotation = new RectangleAnnotation();
                    rectangleAnnotation.Height = 150;
                    rectangleAnnotation.Width = 7;
                    rectangleAnnotation.LineWidth = 1;
                    rectangleAnnotation.LineDashStyle = ChartDashStyle.Solid;
                    rectangleAnnotation.AnchorDataPoint = dp;
                    rectangleAnnotation.BackColor = Color.Transparent;
                    double x = dp.XValue;

                    rectangleAnnotation.Name = $"Annotation{x}";
                    rectangleAnnotation.Text = $"White Marubozu";
                    rectangleAnnotation.IsSizeAlwaysRelative = false;

                    chartStock.Annotations.Add(rectangleAnnotation);
                }
            }
        }

        private bool IsWhiteMarubozu(double low, double high, double open, double close)
        {
            double bodySize = Math.Abs(close - open);
            double range = high - low;
            double distanceToTop = high - Math.Max(open, close);
            bool IsBullish = close > open;

            if (IsBullish == true && bodySize > range * 0.80)
            {
                return true;
            }

            return false;
        }

        /// Black Marubozu method that highlights any Black Marubozu by making a new series called "Black Marubozu" and reads each datapoint to see if they fit the creteria
        private void HighlightBlackMarubozu()
        {


            foreach (DataPoint dp in chartStock.Series["OHLC"].Points)
            {
                if (IsBlackMarubozu(dp.YValues[0], dp.YValues[1], dp.YValues[2], dp.YValues[3]))
                {
                    var rectangleAnnotation = new RectangleAnnotation();
                    rectangleAnnotation.Height = 150;
                    rectangleAnnotation.Width = 7;
                    rectangleAnnotation.LineWidth = 1;
                    rectangleAnnotation.LineDashStyle = ChartDashStyle.Solid;
                    rectangleAnnotation.AnchorDataPoint = dp;
                    rectangleAnnotation.BackColor = Color.Transparent;
                    double x = dp.XValue;

                    rectangleAnnotation.Name = $"Annotation{x}";
                    rectangleAnnotation.Text = $"Black Marubozu";
                    rectangleAnnotation.IsSizeAlwaysRelative = false;

                    chartStock.Annotations.Add(rectangleAnnotation);
                }
            }
        }

        private bool IsBlackMarubozu(double low, double high, double open, double close)
        {
            double bodySize = Math.Abs(close - open);
            double range = high - low;
            bool IsBearish = close < open;

            if (IsBearish == true && bodySize > range * 0.80)
            {
                return true;
            }

            return false;
        }
        /// Bullish Engulfing method that highlights any Bullish Engulfing by making a new series called "Bullish Engulfing" and reads each datapoint to see if they fit the creteria

        private void HighlightBullishEngulfingCandles()
        {




            for (int i = 1; i < chartStock.Series["OHLC"].Points.Count; i++)
            {
                var current = chartStock.Series["OHLC"].Points[i];
                var previous = chartStock.Series["OHLC"].Points[i - 1];

                if (IsBullishEngulfing(current.YValues[0], current.YValues[1], current.YValues[2], current.YValues[3],
                                      previous.YValues[0], previous.YValues[1], previous.YValues[2], previous.YValues[3]))
                {
                    var rectangleAnnotation = new RectangleAnnotation();
                    rectangleAnnotation.Height = 150;
                    rectangleAnnotation.Width = 7;
                    rectangleAnnotation.LineWidth = 1;
                    rectangleAnnotation.LineDashStyle = ChartDashStyle.Solid;
                    rectangleAnnotation.AnchorDataPoint = current;
                    rectangleAnnotation.BackColor = Color.Transparent;
                    double x = current.XValue;

                    rectangleAnnotation.Name = $"Annotation{x}";
                    rectangleAnnotation.Text = $"Black Marubozu";
                    rectangleAnnotation.IsSizeAlwaysRelative = false;

                    chartStock.Annotations.Add(rectangleAnnotation);
                }

            }



        }

        /// Checks each Datapoint to see if they are A bullish Engulfing
        private bool IsBullishEngulfing(double currentLow, double currentHigh, double currentOpen, double currentClose,
                                        double previousLow, double previousHigh, double previousOpen, double previousClose)
        {
            return currentOpen < previousClose && currentClose > previousOpen && currentClose > currentOpen;
        }



        /// Bearish Engulfing method that highlights any Bearish Engulfing by making a new series called "Bearish Engulfing" and reads each datapoint to see if they fit the creteria
        private void HighlightBearishEngulfingCandles()
        {


            for (int i = 1; i < chartStock.Series["OHLC"].Points.Count; i++)
            {
                var current = chartStock.Series["OHLC"].Points[i];
                var previous = chartStock.Series["OHLC"].Points[i - 1];

                if (IsBearishEngulfing(current.YValues[0], current.YValues[1], current.YValues[2], current.YValues[3],
                                           previous.YValues[0], previous.YValues[1], previous.YValues[2], previous.YValues[3]))
                {
                    var rectangleAnnotation = new RectangleAnnotation();
                    rectangleAnnotation.Height = 150;
                    rectangleAnnotation.Width = 7;
                    rectangleAnnotation.LineWidth = 1;
                    rectangleAnnotation.LineDashStyle = ChartDashStyle.Solid;
                    rectangleAnnotation.AnchorDataPoint = current;
                    rectangleAnnotation.BackColor = Color.Transparent;
                    double x = current.XValue;

                    rectangleAnnotation.Name = $"Annotation{x}";
                    rectangleAnnotation.Text = $"Black Marubozu";
                    rectangleAnnotation.IsSizeAlwaysRelative = false;

                    chartStock.Annotations.Add(rectangleAnnotation);
                }
            }



        }
        /// Checks each Datapoint to see if they are A bearish Engulfing
        private bool IsBearishEngulfing(double currentLow, double currentHigh, double currentOpen, double currentClose,
                                        double previousLow, double previousHigh, double previousOpen, double previousClose)
        {
            return currentOpen > previousClose && currentClose < previousOpen && currentClose < currentOpen;
        }



        private void ChartView_Load(object sender, EventArgs e)
        {

        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }

 





        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void comboBoxStockPattern_SelectedIndexChanged(object sender, EventArgs e)
        {
            upDateChart();

            // Get the recognizer for the selected pattern.
            aRecognizer recognizor = recognizors[comboBox_Pattern.SelectedIndex];

            // Get the list of recognized pattern indices.
            List<int> retcon = recognizor.recongize(candlesticks);

            // Deletes the previous annotation.
            chartStock.Annotations.Clear();

            // Loop through each recognized index and add an annotation to the chart.
            foreach (int i in retcon)
            {


                RectangleAnnotation ra = new RectangleAnnotation();
                ra.Text = recognizor.patternName;
                ra.AnchorDataPoint = chartStock.Series["OHLC"].Points[i];
                chartStock.Annotations.Add(ra);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void FormChart_Load(object sender, EventArgs e)
        {

        }
    }
}