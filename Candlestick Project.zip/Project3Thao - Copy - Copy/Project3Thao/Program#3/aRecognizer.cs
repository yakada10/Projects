﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project3
{
    internal abstract class aRecognizer
    {
        // name of pattern recongizer finds 
        public string patternName { get; set; }

        // Size in candlesticks of pattern the recognizer finds.
        public int patternSize { get; set; }

        // Method that tells you if subset matches patterns.
        protected abstract bool patternMatchesSubset(List<aCandlestick> subsetOfCandlesticks);

        /// <summary>
        /// Recognizes patterns in a list of candlesticks.
        /// </summary>
        /// <param name="candlesticks">List of candlesticks to recognize patterns in.</param>
        /// <returns>List of integers representing the indexes where patterns were found.</returns>
        public List<int> recongize(List<aCandlestick> candlesticks)
        {
            List<int> result = new List<int>(candlesticks.Count / 8);

            // Calculate the offset for the pattern size.
            int offset = patternSize - 1;

            // Iterate through the candlesticks, looking for patterns.
            for (int i = offset; i < candlesticks.Count; i++)
            {
                List<aCandlestick> subset = candlesticks.GetRange(i - offset, patternSize);
                if (patternMatchesSubset(subset))
                {
                    result.Add(i);
                }
            }

            // Return the list of indexes where patterns were found.
            return result;
        }

        // Constructor for aRecognizer class.
        public aRecognizer(String pName, int pSize) => (patternName, patternSize) = (pName, pSize);

    }
}