﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Project3
{
    internal class SingleCandlestickRecognizer
    {

    }

    // This class recognizes the Dragon fly doji pattern
    internal class Recognizer_DragonflyDoji : aRecognizer
    {
        public Recognizer_DragonflyDoji() : base("Dragonfly Doji", 1) { }
        protected override bool patternMatchesSubset(List<aCandlestick> subsetOfCandlesticks)
        { return subsetOfCandlesticks[0].isDragonflyDoji; }
    }

    // This class recognizes the neutral pattern
    internal class Recognizer_Neutral : aRecognizer
    {
        // Constructor that sets the name and number of candlesticks required for the neutral pattern
        public Recognizer_Neutral() : base("Neutral", 1) { }

        // Implementation of the patternMatchesSubset method for the neutral pattern
        protected override bool patternMatchesSubset(List<aCandlestick> subsetOfCandlesticks)
        { return subsetOfCandlesticks[0].isNeutral; }

    }

    // This class recognizes the doji pattern
    internal class Recognizer_Doji : aRecognizer
    {
        public Recognizer_Doji() : base("Doji", 1) { }
        protected override bool patternMatchesSubset(List<aCandlestick> subsetOfCandlesticks)
        { return subsetOfCandlesticks[0].isDoji; }
    }

    // This class recognizes the long-legged doji pattern
    internal class Recognizer_LongleggedDoji : aRecognizer
    {
        public Recognizer_LongleggedDoji() : base("Long Legged Doji", 1) { }
        protected override bool patternMatchesSubset(List<aCandlestick> subsetOfCandlesticks)
        { return subsetOfCandlesticks[0].isLongLeggedDoji; }
    }

    // This class recognizesNeutralDoji pattern
    internal class Recognizer_NeutralDoji : aRecognizer
    {
        public Recognizer_NeutralDoji() : base("Neutral Doji", 1) { }
        protected override bool patternMatchesSubset(List<aCandlestick> subsetOfCandlesticks)
        { return subsetOfCandlesticks[0].isNeutralDoji; }

        internal class Recognizer_GravestoneDoji : aRecognizer
        {
            // This class recognizes the Gravestone doji pattern
            public Recognizer_GravestoneDoji() : base("Gravestone Doji", 1) { }
            protected override bool patternMatchesSubset(List<aCandlestick> subsetOfCandlesticks)
            { return subsetOfCandlesticks[0].isGravestoneDoji;
            
            }

            // This class recognizes the bearish pattern
            internal class Recognizer_Bearish : aRecognizer
            {
                public Recognizer_Bearish() : base("Bearish", 1) { }
                protected override bool patternMatchesSubset(List<aCandlestick> subsetOfCandlesticks)
                { return subsetOfCandlesticks[0].isBearish; }
            }

            // This class recognizes the Bullish pattern
            internal class Recognizer_Bullish : aRecognizer
            {
                public Recognizer_Bullish() : base("Bullish", 1) { }
                protected override bool patternMatchesSubset(List<aCandlestick> subsetOfCandlesticks)
                { return subsetOfCandlesticks[0].isBullish; }
            }

            // This class recognizes the long-legged pattern
            internal class Recognizer_LongLegged : aRecognizer
            {
                public Recognizer_LongLegged() : base("LongLegged Doji", 1) { }
                protected override bool patternMatchesSubset(List<aCandlestick> subsetOfCandlesticks)
                { return subsetOfCandlesticks[0].isLongLeggedDoji; }
            }

            // This class recognizes the Hammer pattern
            internal class Recognizer_Hammer : aRecognizer
            {
                public Recognizer_Hammer() : base("Hammer", 1) { }
                protected override bool patternMatchesSubset(List<aCandlestick> subsetOfCandlesticks)
                { return subsetOfCandlesticks[0].isHammer; }
            }

            // This class recognizes the bullish hammer pattern
            internal class Recognizer_BullishHammer : aRecognizer
            {
                public Recognizer_BullishHammer() : base("Bullish Hammer", 1) { }
                protected override bool patternMatchesSubset(List<aCandlestick> subsetOfCandlesticks)
                { return subsetOfCandlesticks[0].isBullishHammer; }
            }

            // This class recognizes the Bearish Hammer pattern
            internal class Recognizer_BearishHammer : aRecognizer
            {
                public Recognizer_BearishHammer() : base("Bearish Hammer", 1) { }
                protected override bool patternMatchesSubset(List<aCandlestick> subsetOfCandlesticks)
                { return subsetOfCandlesticks[0].isBearishHammer; }
            }

            // This class recognizes the Inverted Hammer pattern
            internal class Recognizer_InvertedHammer : aRecognizer
            {
                public Recognizer_InvertedHammer() : base("Inverted Hammer", 1) { }
                protected override bool patternMatchesSubset(List<aCandlestick> subsetOfCandlesticks)
                { return subsetOfCandlesticks[0].isInvertedHammer; }
            }

            // This class recognizes the Bullish Inverted Hammer pattern
            internal class Recognizer_BullishInvertedHammer : aRecognizer
            {
                public Recognizer_BullishInvertedHammer() : base("Bullish Inverted Hammer", 1) { }
                protected override bool patternMatchesSubset(List<aCandlestick> subsetOfCandlesticks)
                { return subsetOfCandlesticks[0].isBullishInvertedHammer; }
            }

            // This class recognizes the Bearish Inverted Hammer pattern
            internal class Recognizer_BearishInvertedHammer : aRecognizer
            {
                public Recognizer_BearishInvertedHammer() : base("Bearish Inverted Hammer", 1) { }
                protected override bool patternMatchesSubset(List<aCandlestick> subsetOfCandlesticks)
                { return subsetOfCandlesticks[0].isBearishInvertedHammer; }
            }

            // This class recognizes the Marubozu pattern
            internal class Recognizer_Marubozu : aRecognizer
            {
                public Recognizer_Marubozu() : base("Marubozu", 1) { }
                protected override bool patternMatchesSubset(List<aCandlestick> subsetOfCandlesticks)
                { return subsetOfCandlesticks[0].isMarubozu; }
            }

            // This class recognizes the White Marubozu pattern
            internal class Recognizer_WhiteMarubozu : aRecognizer
            {
                public Recognizer_WhiteMarubozu() : base("White Marubozu", 1) { }
                protected override bool patternMatchesSubset(List<aCandlestick> subsetOfCandlesticks)
                { return subsetOfCandlesticks[0].isWhiteMarubozu; }
            }

            // This class recognizes the Black Marubozu pattern
            internal class Recognizer_BlackMarubozu : aRecognizer
            {
                public Recognizer_BlackMarubozu() : base("Black Marubozu", 1) { }
                protected override bool patternMatchesSubset(List<aCandlestick> subsetOfCandlesticks)
                { return subsetOfCandlesticks[0].isBlackMarubozu; }
            }

            }

        }
}