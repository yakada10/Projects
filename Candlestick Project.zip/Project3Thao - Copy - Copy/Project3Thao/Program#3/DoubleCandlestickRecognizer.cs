﻿using System;
using System.Collections.Generic;
using System.Deployment.Internal;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms.DataVisualization.Charting;

namespace Project3
{
    internal class BullishDoubleRecognizer : aRecognizer
    {
        // Constructor that calls the base constructor with "Bearish Engulfing Pattern" and 2 as parameters
        public BullishDoubleRecognizer() : base("Bearish Engulfing Pattern", 2) { }

        // Override the patternMatchesSubset method
        protected override bool patternMatchesSubset(List<aCandlestick> Lcs)
        {
            // Get the first and second candlesticks in the list
            aCandlestick pcs = Lcs[0];
            aCandlestick cs = Lcs[1];

            // Check if the first candlestick is bearish, second is bullish, and the second's topPrice is greater than the first's high and bottomPrice is less than the first's low
            return pcs.isBearish && cs.isBullish && pcs.High < cs.topPrice && pcs.Low > cs.bottomPrice;
        }
    }

    // Define internal class BearishDoubleRecognizer, which extends aRecognizer
    internal class BearishDoubleRecognizer : aRecognizer
    {
        // Constructor that calls the base constructor with "Bearish Engulfing Pattern" and 2 as parameters
        public BearishDoubleRecognizer() : base("Bearish Engulfing Pattern", 2) { }

        // Override the patternMatchesSubset method
        protected override bool patternMatchesSubset(List<aCandlestick> Lcs)
        {
            // Get the first and second candlesticks in the list
            aCandlestick pcs = Lcs[0];
            aCandlestick cs = Lcs[1];

            // Check if the first candlestick is bullish, second is bearish, and the second's topPrice is greater than the first's high and bottomPrice is less than the first's low
            return pcs.isBullish && cs.isBearish && pcs.High < cs.topPrice && pcs.Low > cs.bottomPrice;
        }
    }



}
